# SocietyManagementSystem


# Introduction -
Hii all, my name is Shriyash  Thakare, As our PG Project we have selected topic of "Society Management System".


# Project Objective -
The Project is developed to demonstrate the learning obtained during the course and resolve the
issue of Buyers. In my project we have Implementing a User Friendly Web Application. designed to
help manage the day-to-day operation of residential socities , housing complexes, or gated
communities it aims to simplify and automate the management of residential socities.


# Project Description - ( coming to Technologies..)
The project is developed by in react as its frontend using node as a platform which is a library of JS,
where are handling the client facing request and portal design.

for database we have ued MYSql to store our society, secretary, owner and other related details.
for the backend we have choosen ExpressJs, NodeJs. NodeJS Is open source , cross platform JS
runtime environment. Backend APIs it handle routing and CORS is used to restrict resources on a
web server based on the origin of the request. 
# For Security we have use JsonWebToken And SHA256 Hashing algorithum.
CryptoJS is used to handle cryptographic operations such as hashing
and encryption.

After completing the backend development, I designed and built a comprehensive society
management system using ReactJS, featuring three distinct dashboards: Admin, Secretary, and
Owner.

The Admin dashboard, which is unique to each society, serves as the central hub for managing
societies and their respective secretaries. From this dashboard, administrators can add new societies
and assign secretaries to manage them. However, to prevent data inconsistencies, administrators
cannot delete societies that have already been assigned a secretary.
The Secretary dashboard is where secretaries can add new owners to their respective societies,
assigning each owner a unique ID. This allows owners to access information specific to their
society, including amenities and announcements.
Finally, the Owner dashboard provides a personalized view, displaying only the owner's relevant
information, announcements, and amenities that have been added by their secretary. This ensures
that owners can easily access the information they need, while maintaining the security and
integrity of the system.
Owner Which Are potential User on the portal. when the owner Navigates to the portal, they can
login in by Using Email and password as a method of Authentication and Password Encyption.
The provided user credentials are verified with the credentials stored in the database. on successfull
authentication, the Owner is navigated to the Owner's dashboard.


# Personal Contribution -
These is The Group Project , We have 5 Members in group.
Now Coming to my personal Contribution i have contribute in the development and design frontend
and database. design modules of the project related to society managment, Homepage
development, Admin Owner Dashboard development.


# Run The WebPage - 
   # Backend - ( Using NodeJS )
      - node server.js

   # Frontend -  ( Using ReactJS )
      - npm start
